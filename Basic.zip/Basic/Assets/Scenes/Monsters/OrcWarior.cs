using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrcWarior : Orc
{
    // Start is called before the first frame update
    void Start()
    {
        hp = 80;
        level = 2;
        damage = 40;
        gold = 120;
        MonsterInfo();
        WarCry();
    }
}
