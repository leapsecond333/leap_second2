using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slime : Monster
{
    // Start is called before the first frame update
    void Start()
    {
        hp = 200;
        level = 1;
        damage = 12;
        gold = 50;
        MonsterInfo();
    }
    protected virtual void SlimeSplit()
    {
        Debug.Log("������ �п�!!");
    }
}
