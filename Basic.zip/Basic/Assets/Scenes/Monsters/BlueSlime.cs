using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueSlime : Slime
{
    // Start is called before the first frame update
    void Start()
    {
        hp = 220;
        level = 2;
        damage = 16;
        gold = 80;
        MonsterInfo();
        SlimeSplit();
    }
}
