using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrcMagician : Orc
{
    // Start is called before the first frame update
    void Start()
    {
        hp = 40;
        level = 2;
        damage = 30;
        gold = 100;
        MonsterInfo();
        WarCry();
    }
}
