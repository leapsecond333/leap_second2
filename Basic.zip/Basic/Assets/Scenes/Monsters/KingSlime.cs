using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KingSlime : Slime
{
    // Start is called before the first frame update
    void Start()
    {
        hp = 500;
        level = 3;
        damage = 30;
        gold = 200;
        MonsterInfo();
        SlimeSplit();
    }
    protected virtual void SummonSlime()
    {
        Debug.Log("������ ��ȯ!!");
    }
}
