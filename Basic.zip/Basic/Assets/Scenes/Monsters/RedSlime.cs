using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedSlime : Slime
{
    // Start is called before the first frame update
    void Start()
    {
        hp = 160;
        level = 2;
        damage = 20;
        gold = 60;
        MonsterInfo();
        SlimeSplit();
    }
}
