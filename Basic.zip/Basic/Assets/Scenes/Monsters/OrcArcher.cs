using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrcArcher : Orc
{
    // Start is called before the first frame update
    void Start()
    {
        hp = 50;
        level = 2;
        damage = 30;
        gold = 100;
        MonsterInfo();
        WarCry();
    }
}
