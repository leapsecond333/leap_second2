using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// �ڵ����� �߻�ȭ
public class Car : MonoBehaviour
{
    public string carName;
    public string price;
    public int wheelDrive;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
