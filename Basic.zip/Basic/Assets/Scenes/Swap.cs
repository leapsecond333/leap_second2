using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Swap : MonoBehaviour
{
    int a = 100;
    int b = -300;
    // Start is called before the first frame update
    void Start()
    {
        int c = a;
        a = b;
        b = c;
        Debug.Log(a);
        Debug.Log(b);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
