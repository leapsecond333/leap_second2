using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NumberBaseBall : MonoBehaviour
{
    public Button buttonStart;
    public Button buttonOne;
    public Button buttonTwo;
    public Button buttonThree;
    public Button buttonFour;
    public Button buttonFive;
    public Button buttonSix;
    public Button buttonSeven;
    public Button buttonEight;
    public Button buttonNine;
    public Button buttonReset;
    public Button buttonThrow;
    public TextMeshProUGUI Typing;

    int ComputerNum = 0;
    int collectNumCount = 0;
    int sameNumCount = 0;
    string[] userNumber = { "", "", "" };
    int userNumberindex = 0;
    int Ball = 0;
    int Out = 0;
    bool isGameStart = false;
    public List<int> Number = new List<int>();

    // Start is called before the first frame update
    void Start()
    {
        // ��ư �Լ� ����
        buttonStart.onClick.AddListener(StartButton);
        buttonOne.onClick.AddListener(One);
        buttonTwo.onClick.AddListener(Two);
        buttonThree.onClick.AddListener(Three);
        buttonFour.onClick.AddListener(Four);
        buttonFive.onClick.AddListener(Five);
        buttonSix.onClick.AddListener(Six);
        buttonSeven.onClick.AddListener(Seven);
        buttonEight.onClick.AddListener(Eight);
        buttonNine.onClick.AddListener(Nine);
        buttonReset.onClick.AddListener(RESET);
        buttonThrow.onClick.AddListener(THROW);
    }
    void StartButton()
    {
        StartingGame();
    }
    void One()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(1);
                userNumber[userNumberindex] = "1";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void Two()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(2);
                userNumber[userNumberindex] = "2";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void Three()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(3);
                userNumber[userNumberindex] = "3";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void Four()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(4);
                userNumber[userNumberindex] = "4";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void Five()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(5);
                userNumber[userNumberindex] = "5";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void Six()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(6);
                userNumber[userNumberindex] = "6";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void Seven()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(7);
                userNumber[userNumberindex] = "7";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void Eight()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(8);
                userNumber[userNumberindex] = "8";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void Nine()
    {
        if (isGameStart == true) if (Number.Count != 6)
            {
                Number.Add(9);
                userNumber[userNumberindex] = "9";
                userNumberindex++;
                Typing.text = userNumber[0] + userNumber[1] + userNumber[2];
            }
    }
    void RESET()
    {
        for (int i = 0; i < 5; i++)
        {
            Number.RemoveAt(i);
        }
    }
    void THROW()
    {
        for (int i = 0; i < 3; i++)
        {
            if (Number[i % 3] == Number[(i % 3) + 3]) collectNumCount++;
        }
        if (Number[0] == Number[4]) sameNumCount++;
        if (Number[0] == Number[5]) sameNumCount++;
        if (Number[1] == Number[3]) sameNumCount++;
        if (Number[1] == Number[5]) sameNumCount++;
        if (Number[2] == Number[3]) sameNumCount++;
        if (Number[2] == Number[4]) sameNumCount++;
        if (collectNumCount > 3)
        {
            Typing.text = "��Ʈ����ũ";
        }
        else if (sameNumCount > 0)  // ���� �߰� ���� �ٽ� ���� �Է��Ϸ��ϸ� "��"�� �� �����
        {
            Typing.text = "��";
            Ball++;
        }
        else
        {
            Typing.text = "�ƿ�";
            Ball++;
            Out++;
        }
    }
    void StartingGame()
    {
        Ball = 0;
        Out = 0;
        collectNumCount = 0;
        sameNumCount = 0;
        userNumberindex = 0;
        if (Number.Count != 0)
        {
            for (int i = 0; i < Number.Count; i++)
            {
                Number.RemoveAt(i);
            }
        }
        for (int i = 0; i < 3; i++)
        {
            ComputerNum = Random.Range(1, 10);
            Number.Add(ComputerNum);
        }
        isGameStart = true;
    }
    void Update()
    {
        if (Ball > 12 || Out > 3)
        {
            Typing.text = "�й�";
            isGameStart = false;
        }
    }
}
